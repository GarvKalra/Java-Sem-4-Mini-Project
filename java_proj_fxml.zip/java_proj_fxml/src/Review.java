/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 91995
 */
public class Review {
    private String restaurantName;
    private String reviewText;

    public Review(String restaurantName, String reviewText) {
        this.restaurantName = restaurantName;
        this.reviewText = reviewText;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public String getReviewText() {
        return reviewText;
    }
}

