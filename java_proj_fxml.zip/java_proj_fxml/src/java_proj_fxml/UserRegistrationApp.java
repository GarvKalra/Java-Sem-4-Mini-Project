/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 91995
 */
/*import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Random;

// Custom Exception Classes
class InvalidUserDetailsException extends IllegalArgumentException {
    public InvalidUserDetailsException(String message) {
        super(message);
    }
}

class InvalidAddressException extends IllegalArgumentException {
    public InvalidAddressException(String message) {
        super(message);
    }
}

interface Validatable {
    boolean isValid();
}

// Address class with enhanced exception handling
class Address implements Validatable {
    private int addressId;
    private int customerId;
    private String line1;
    private String line2;
    private String city;
    private String state;
    private String postalCode;

    public Address(int addressId, int customerId, String line1, String line2, String city, String state, String postalCode) {
        this.addressId = addressId;
        this.customerId = customerId;
        this.line1 = line1;
        this.line2 = line2;
        this.city = city;
        this.state = state;
        this.postalCode = postalCode;
    }

    @Override
    public boolean isValid() {
        String regex = "\\d{5}(-\\d{4})?";
        if (postalCode == null || !postalCode.matches(regex)) {
            throw new InvalidAddressException("Invalid Postal Code: " + postalCode);
        }
        return true;
    }
}

// User class with enhanced exception handling
abstract class User implements Validatable {
    protected int userId;
    protected int accountId;
    protected String firstName;
    protected String lastName;
    protected String phoneNumber;
    protected String email;

    public User(int userId, int accountId, String firstName, String lastName, String phoneNumber, String email) {
        this.userId = userId;
        this.accountId = accountId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public abstract boolean isValid();
}

// Customer class with enhanced exception handling
class Customer extends User {
    private LocalDate lastOrderDate;

    public Customer(int userId, int accountId, String firstName, String lastName, String phoneNumber, String email, LocalDate lastOrderDate) {
        super(userId, accountId, firstName, lastName, phoneNumber, email);
        this.lastOrderDate = lastOrderDate;
    }

    @Override
    public boolean isValid() {
        if (firstName == null || lastName == null || email == null || phoneNumber == null) {
            throw new InvalidUserDetailsException("All fields must be filled");
        }
        if (!firstName.matches("[a-zA-Z]+")) {
            throw new InvalidUserDetailsException("First Name should not contain numbers");
        }
        if (!lastName.matches("[a-zA-Z]+")) {
            throw new InvalidUserDetailsException("Last Name should not contain numbers");
        }
        if (!email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")) {
            throw new InvalidUserDetailsException("Invalid Email Format");
        }
        if (!phoneNumber.matches("\\d{10}")) {
            throw new InvalidUserDetailsException("Phone Number should be exactly 10 digits");
        }
        return true;
    }
}

// Admin class with enhanced exception handling
class Admin extends User {
    private String username;
    private String password;
    private boolean isActive;

    public Admin(int userId, int accountId, String firstName, String lastName, String phoneNumber, String email, String username, String password, boolean isActive) {
        super(userId, accountId, firstName, lastName, phoneNumber, email);
        this.username = username;
        this.password = password;
        this.isActive = isActive;
    }

    @Override
    public boolean isValid() {
        if (firstName == null || lastName == null || email == null || phoneNumber == null) {
            throw new InvalidUserDetailsException("All fields must be filled");
        }
        if (!firstName.matches("[a-zA-Z]+")) {
            throw new InvalidUserDetailsException("First Name should not contain numbers");
        }
        if (!lastName.matches("[a-zA-Z]+")) {
            throw new InvalidUserDetailsException("Last Name should not contain numbers");
        }
        if (!email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")) {
            throw new InvalidUserDetailsException("Invalid Email Format");
        }
        if (!phoneNumber.matches("\\d{10}")) {
            throw new InvalidUserDetailsException("Phone Number should be exactly 10 digits");
        }
        if (username == null || password == null) {
            throw new InvalidUserDetailsException("Invalid Admin Details: " + firstName + " " + lastName);
        }
        return true;
    }
}

// GUI Class for User Registration
public class UserRegistrationApp extends Application {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/food_ordering_system2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "#Blossom84#";

    private Connection conn;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("User Registration");

        // Creating labels
        Label firstNameLabel = new Label("First Name:");
        Label lastNameLabel = new Label("Last Name:");
        Label emailLabel = new Label("Email:");
        Label phoneNumberLabel = new Label("Phone Number:");
        Label addressLabel = new Label("Address:");

        // Creating text fields
        TextField firstNameField = new TextField();
        TextField lastNameField = new TextField();
        TextField emailField = new TextField();
        TextField phoneNumberField = new TextField();
        TextField addressField = new TextField();

        // Creating register button
        Button registerButton = new Button("Register");
        registerButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        registerButton.setOnAction(event -> {
            try {
                // Validate user details
                Customer customer = new Customer(1, generateRandomId(), firstNameField.getText(), lastNameField.getText(), phoneNumberField.getText(), emailField.getText(), LocalDate.now());
                customer.isValid();

                // Validate address
                Address address = new Address(1, 1, addressField.getText(), "", "", "", "00000");
                address.isValid();

                // Insert into database
                insertIntoDatabase(customer);

                // If insertion is successful, show success message
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Registration Successful");
                alert.setHeaderText(null);
                alert.setContentText("User registered successfully!");
                alert.showAndWait();
            } catch (InvalidUserDetailsException | InvalidAddressException | SQLException e) {
                // If validation fails or database operation fails, show error message
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Registration Error");
                alert.setHeaderText(null);
                alert.setContentText(e.getMessage());
                alert.showAndWait();
            }
        });

        // Creating grid pane
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20, 20, 20, 20));
        gridPane.setVgap(10);
        gridPane.setHgap(10);

        // Adding components to the grid pane
        gridPane.add(firstNameLabel, 0, 0);
        gridPane.add(firstNameField, 1, 0);
        gridPane.add(lastNameLabel, 0, 1);
        gridPane.add(lastNameField, 1, 1);
        gridPane.add(emailLabel, 0, 2);
        gridPane.add(emailField, 1, 2);
        gridPane.add(phoneNumberLabel, 0, 3);
        gridPane.add(phoneNumberField, 1, 3);
        gridPane.add(addressLabel, 0, 4);
        gridPane.add(addressField, 1, 4);
        gridPane.add(registerButton, 1, 5);

        // Setting grid pane alignment
        gridPane.setAlignment(Pos.CENTER);

        // Creating scene
        Scene scene = new Scene(gridPane, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();

        // Initialize database connection
        try {
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Connected to the database");
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    // Method to generate random IDs
    private int generateRandomId() {
        Random random = new Random();
        return random.nextInt(1000); // Change the upper limit as needed
    }

    // Method to insert user data into the database
    private void insertIntoDatabase(Customer customer) throws SQLException {
        String query = "INSERT INTO Account (email, first_name, last_name, phone_number, registration_date, is_active) VALUES ( ?, ?, ?, ?, CURDATE(), 1)";

        try (PreparedStatement statement = conn.prepareStatement(query)) {
            statement.setString(1, customer.email);
            statement.setString(2, customer.firstName);
            statement.setString(3, customer.lastName);
            statement.setString(4, customer.phoneNumber);

            statement.executeUpdate();
        }
    }
}
*/
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_proj_fxml;

/**
 *
 * @author 91995
 */

/**
 *
 * @author 91995
 */

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Random;

// Custom Exception Classes
class InvalidUserDetailsException extends IllegalArgumentException {
    public InvalidUserDetailsException(String message) {
        super(message);
    }
}

class InvalidAddressException extends IllegalArgumentException {
    public InvalidAddressException(String message) {
        super(message);
    }
}

interface Validatable {
    boolean isValid();
}

class Address implements Validatable {
    private int addressId;
    private int customerId;
    private String line1;
    private String line2;
    private String city;
    private String state;
    private String postalCode;

    public Address(int addressId, int customerId, String line1, String line2, String city, String state, String postalCode) {
        this.addressId = addressId;
        this.customerId = customerId;
        this.line1 = line1;
        this.line2 = line2;
        this.city = city;
        this.state = state;
        this.postalCode = postalCode;
    }

    @Override
    public boolean isValid() {
        String regex = "\\d{5}(-\\d{4})?";
        if (postalCode == null || !postalCode.matches(regex)) {
            throw new InvalidAddressException("Invalid Postal Code: " + postalCode);
        }
        return true;
    }
}

abstract class User implements Validatable {
    protected int userId;
    protected int accountId;
    protected String firstName;
    protected String lastName;
    protected String phoneNumber;
    protected String email;

    public User(int userId, int accountId, String firstName, String lastName, String phoneNumber, String email) {
        this.userId = userId;
        this.accountId = accountId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public abstract boolean isValid();
}

class Customer extends User {
    private LocalDate lastOrderDate;
    protected String password;
    public Customer(int userId, int accountId, String firstName, String lastName, String phoneNumber, String email, String password, LocalDate lastOrderDate) {
        super(userId, accountId, firstName, lastName, phoneNumber, email);
        this.password = password;
        this.lastOrderDate = lastOrderDate;
    }

    @Override
    public boolean isValid() {
        if (firstName == null || lastName == null || email == null || phoneNumber == null) {
            throw new InvalidUserDetailsException("All fields must be filled");
        }
        if (!firstName.matches("[a-zA-Z]+")) {
            throw new InvalidUserDetailsException("First Name should not contain numbers");
        }
        if (!lastName.matches("[a-zA-Z]+")) {
            throw new InvalidUserDetailsException("Last Name should not contain numbers");
        }
        if (!email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")) {
            throw new InvalidUserDetailsException("Invalid Email Format");
        }
        if (!phoneNumber.matches("\\d{10}")) {
            throw new InvalidUserDetailsException("Phone Number should be exactly 10 digits");
        }
        if (password == null || password.isEmpty()) {
            throw new InvalidUserDetailsException("Password cannot be empty");
        }
        return true;
    }
}

public class UserRegistrationApp extends Application {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/food_ordering_system2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "#Blossom84#";

    private Connection conn;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("User Registration");

        // Creating labels
        Label firstNameLabel = new Label("First Name:");
        Label lastNameLabel = new Label("Last Name:");
        Label emailLabel = new Label("Email:");
        Label phoneNumberLabel = new Label("Phone Number:");
        Label addressLabel = new Label("Address:");
        Label passwordLabel = new Label("Password:");

        // Creating text fields
        TextField firstNameField = new TextField();
        TextField lastNameField = new TextField();
        TextField emailField = new TextField();
        TextField phoneNumberField = new TextField();
        TextField addressField = new TextField();
        PasswordField passwordField = new PasswordField();

        // Creating register button
        Button registerButton = new Button("Register");
        registerButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        registerButton.setOnAction(event -> {
            try {
                Customer customer = new Customer(1, generateRandomId(), firstNameField.getText(), lastNameField.getText(), phoneNumberField.getText(), emailField.getText(), passwordField.getText(), LocalDate.now());
                customer.isValid();

                Address address = new Address(1, 1, addressField.getText(), "", "", "", "00000");
                address.isValid();

                insertIntoDatabase(customer);

                // If insertion is successful, show success message
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Registration Successful");
                alert.setHeaderText(null);
                alert.setContentText("User registered successfully!");
                alert.showAndWait();
            } catch (InvalidUserDetailsException | InvalidAddressException | SQLException e) {
                // If validation fails or database operation fails, show error message
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Registration Error");
                alert.setHeaderText(null);
                alert.setContentText(e.getMessage());
                alert.showAndWait();
            }
        });

        // Creating grid pane
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20, 20, 20, 20));
        gridPane.setVgap(10);
        gridPane.setHgap(10);

        gridPane.add(firstNameLabel, 0, 0);
        gridPane.add(firstNameField, 1, 0);
        gridPane.add(lastNameLabel, 0, 1);
        gridPane.add(lastNameField, 1, 1);
        gridPane.add(emailLabel, 0, 2);
        gridPane.add(emailField, 1, 2);
        gridPane.add(phoneNumberLabel, 0, 3);
        gridPane.add(phoneNumberField, 1, 3);
        gridPane.add(addressLabel, 0, 4);
        gridPane.add(addressField, 1, 4);
        gridPane.add(passwordLabel, 0, 5);
        gridPane.add(passwordField, 1, 5);
        gridPane.add(registerButton, 1, 6);

        gridPane.setAlignment(Pos.CENTER);

        Scene scene = new Scene(gridPane, 400, 350);
        primaryStage.setScene(scene);
        primaryStage.show();

        try {
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Connected to the database");
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    private int generateRandomId() {
        Random random = new Random();
        return random.nextInt(1000); 
    }

    private void insertIntoDatabase(Customer customer) throws SQLException {
        String query = "INSERT INTO Account (email, password, first_name, last_name, phone_number, registration_date, is_active) VALUES (?, ?, ?, ?, ?, CURDATE(), 1)";

        try (PreparedStatement statement = conn.prepareStatement(query)) {
            statement.setString(1, customer.email);
            statement.setString(2, customer.password);
            statement.setString(3, customer.firstName);
            statement.setString(4, customer.lastName);
            statement.setString(5, customer.phoneNumber);

            statement.executeUpdate();
        }
    }
}