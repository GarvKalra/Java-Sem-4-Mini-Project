/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template








 */
package java_proj_fxml;

/**
 *
 * @author 91995
 */
import javafx.scene.control.ButtonType;

import javafx.scene.control.Alert;
import javafx.scene.control.TableRow;
import javafx.scene.control.TextInputDialog;
import java.util.*;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.application.Application;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.stage.Stage;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/*import javafx.application.Application;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;

import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
*/
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import java.sql.*;
import javafx.beans.property.IntegerProperty;

public class MainDashboard extends Application {
      TableView<Restaurant2> tableView;
      TableView<Order2> tableView2 = new TableView<>();
      private TableColumn<Restaurant2, String> nameCol;
     private TableColumn<Restaurant2, String> addressCol;
     private final String url = "jdbc:mysql://localhost:3306/food_ordering_system2";
     private final String username = "root";
     private final String password = "your_passwd";
      
    @Override
    
    
    public void start(Stage primaryStage) {
        
        Label titleLabel = new Label("Food Ordering Management System");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-text-fill: #333333;");

        HBox headerBox = new HBox(titleLabel);
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setPadding(new Insets(20));
        headerBox.setStyle("-fx-background-color: #f0f0f0;");

        Label welcomeLabel = new Label("Welcome Back, Admin");
        welcomeLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: #333333;");
        HBox.setMargin(welcomeLabel, new Insets(0, 0, 10, 0)); 

        VBox headerSection = new VBox(headerBox, welcomeLabel); 
        headerSection.setAlignment(Pos.CENTER);
        headerSection.setPadding(new Insets(20));

        VBox overviewBox = new VBox();
        overviewBox.setSpacing(20);
        overviewBox.setPadding(new Insets(20));
        overviewBox.setAlignment(Pos.CENTER_LEFT);

        Label overviewLabel = new Label("Overview");
        overviewLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: #333333;");

        Button viewOrdersButton = new Button("View Orders");
        viewOrdersButton.setOnAction(e -> openOrdersWindow());
        viewOrdersButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        Button customersButton = new Button("View Customers");
        Button restaurantsButton = new Button("View Restaurants");
        restaurantsButton.setOnAction(e -> openRestaurantsWindow());
        customersButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
        restaurantsButton.setStyle("-fx-background-color: #FF5722; -fx-text-fill: white;");

        overviewBox.getChildren().addAll(overviewLabel, viewOrdersButton, customersButton, restaurantsButton);

        // Main Layout
        VBox mainLayout = new VBox(headerSection, overviewBox);
        mainLayout.setStyle("-fx-background-color: #ffffff;");

        Scene scene = new Scene(mainLayout, 600, 400); // Increase window size

        primaryStage.setScene(scene);
        primaryStage.setTitle("Food Ordering Management Dashboard");
        primaryStage.show();
    }

    private void initializeTableView() {
    tableView = new TableView<>();

    nameCol = new TableColumn<>("Name");
    nameCol.setCellValueFactory(data -> data.getValue().nameProperty());
    

    addressCol = new TableColumn<>("Address");
    addressCol.setCellValueFactory(data -> data.getValue().addressProperty());
    // Add columns to the TableView
    tableView.getColumns().addAll(nameCol, addressCol);
    
    ObservableList<Restaurant2> restaurants = fetchRestaurantsFromDatabase();
    tableView.setItems(restaurants);
}

private void refreshTableView() {
    ObservableList<Restaurant2> restaurants = fetchRestaurantsFromDatabase();
    tableView.setItems(restaurants);
}
    
   private void handleUpdate() {
    Restaurant2 selectedRestaurant = tableView.getSelectionModel().getSelectedItem();
    if (selectedRestaurant != null) {
        String oldName = selectedRestaurant.getName();
        String oldAddress = selectedRestaurant.getAddress();
        
        TextInputDialog dialog = new TextInputDialog(selectedRestaurant.getName());
        dialog.setTitle("Update Restaurant");
        dialog.setHeaderText("Enter new details for the restaurant:");
        dialog.setContentText("Name:");
        Optional<String> resultName = dialog.showAndWait();
        
        if (resultName.isPresent()) {
            String newName = resultName.get();
            
            dialog = new TextInputDialog(selectedRestaurant.getAddress());
            dialog.setHeaderText("Enter new address for the restaurant:");
            dialog.setContentText("Address:");
            Optional<String> resultAddress = dialog.showAndWait();
            
            if (resultAddress.isPresent()) {
                String newAddress = resultAddress.get();
                
                selectedRestaurant.setName(newName);
                selectedRestaurant.setAddress(newAddress);

                tableView.refresh();

                updateRestaurantInDatabase(selectedRestaurant, oldName, oldAddress);
            }
        }
    } else {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("No Restaurant Selected");
        alert.setContentText("Please select a restaurant to update.");
        alert.showAndWait();
    }
}

private void updateRestaurantInDatabase(Restaurant2 restaurant, String oldName, String oldAddress) {

    String sql = "UPDATE restaurant SET name = ?, address = ? WHERE name = ? AND address = ?";

    try (
        Connection conn = DriverManager.getConnection(url, username, password);
        PreparedStatement statement = conn.prepareStatement(sql);
    ) {
        statement.setString(1, restaurant.getName()); 
        statement.setString(2, restaurant.getAddress()); 
        statement.setString(3, oldName); 
        statement.setString(4, oldAddress); 

        int rowsUpdated = statement.executeUpdate();

        if (rowsUpdated > 0) {
            System.out.println("Restaurant updated successfully!");
        } else {
            System.out.println("Restaurant not found or failed to update.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}


    private void handleDelete() {
    Restaurant2 selectedRestaurant = tableView.getSelectionModel().getSelectedItem();
    if (selectedRestaurant != null) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Deletion");
        alert.setHeaderText("Delete Restaurant");
        alert.setContentText("Are you sure you want to delete the selected restaurant?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            tableView.getItems().remove(selectedRestaurant); // Remove from TableView
            deleteRestaurantFromDatabase(selectedRestaurant); // Delete from the database
        }
    } else {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("No Restaurant Selected");
        alert.setContentText("Please select a restaurant to delete.");
        alert.showAndWait();
    }
}

private void deleteRestaurantFromDatabase(Restaurant2 restaurant) {
    

    String sql = "DELETE FROM restaurant WHERE name = ?";

    try (
        Connection conn = DriverManager.getConnection(url, username, password);
        PreparedStatement statement = conn.prepareStatement(sql);
    ) {
         statement.setString(1, restaurant.getName());
        
        int rowsDeleted = statement.executeUpdate();
        
        if (rowsDeleted > 0) {
            System.out.println("Restaurant deleted successfully!");
        } else {
            System.out.println("Restaurant not found or failed to delete.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    
 private void handleInsert() {
    TextInputDialog dialog = new TextInputDialog();
    dialog.setTitle("Insert Restaurant");
    dialog.setHeaderText("Enter the name and address of the restaurant:");
    dialog.setContentText("Name:");
    
    Optional<String> result = dialog.showAndWait();
    
    result.ifPresent(name -> {
        TextInputDialog addressDialog = new TextInputDialog();
        addressDialog.setTitle("Insert Restaurant");
        addressDialog.setHeaderText("Enter the address of the restaurant:");
        addressDialog.setContentText("Address:");
        
        Optional<String> addressResult = addressDialog.showAndWait();
        
        addressResult.ifPresent(address -> {
            insertRestaurantIntoDatabase(name, address);
            // Refresh TableView with updated data
            tableView.setItems(fetchRestaurantsFromDatabase());
        });
    });
}

private void insertRestaurantIntoDatabase(String name, String address) {
    try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/food_ordering_system2", username, password)) {
        //String query = "INSERT INTO restaurant (restaurant_id,name, address) VALUES (6,?, ?)";
        String query = "INSERT INTO restaurant (name, address) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, name);
            statement.setString(2, address);
            statement.executeUpdate();
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}   
private void openRestaurantsWindow() {
    if (tableView == null) {
        initializeTableView();
    } else {
        tableView.getItems().clear();
        initializeTableView();
    }
    Stage restaurantsStage = new Stage();
    restaurantsStage.setTitle("Restaurants");

    //TableView<Restaurant> tableView = new TableView<>();
    //TableColumn<Restaurant, String> nameCol = new TableColumn<>("Name");
    //nameCol.setCellValueFactory(data -> data.getValue().nameProperty());
    //addressCol.setCellValueFactory(data -> data.getValue().addressProperty());
    //TableColumn<Restaurant, String> addressCol = new TableColumn<>("Address");
    //addressCol.setCellValueFactory(data -> data.getValue().addressProperty());

    // Add more columns as needed (e.g., rating, phone number)

    //tableView.getColumns().addAll(nameCol, addressCol);

    //ObservableList<Restaurant> restaurants = fetchRestaurantsFromDatabase();
    //tableView.setItems(restaurants);
    
    Button insertButton = new Button("Insert");
    insertButton.setOnAction(e -> handleInsert());
    insertButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
    
    Button deleteButton = new Button("delete selected restaurant");
    deleteButton.setOnAction(e -> handleDelete());
    deleteButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
    
    Button updateButton = new Button("update selected restaurant");
    updateButton.setOnAction(e -> handleUpdate());
    updateButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
    
    
    HBox buttonsBox = new HBox(insertButton, deleteButton);
    buttonsBox.setAlignment(Pos.CENTER); // Align buttons horizontally
    buttonsBox.setSpacing(10);
    tableView.setRowFactory(tv -> new TableRow<Restaurant2>() {
    @Override
    protected void updateItem(Restaurant2 item, boolean empty) {
        super.updateItem(item, empty);
        if (item == null || empty) {
            setStyle("");
        } else {
            // Specify conditions to hide rows based on the data values
            if (item.getName() == null) { // Example condition
                setStyle("-fx-background-color: transparent;");
            } else {
                setStyle("");
            }
        }
    }
});
 
    
    
    VBox layout = new VBox(tableView);
    layout.setPadding(new Insets(30));
    layout.setSpacing(30);

    Scene scene = new Scene(layout, 400, 300);
    restaurantsStage.setScene(scene);
    restaurantsStage.setTitle("Restaurants");
    restaurantsStage.show();
    layout.getChildren().addAll(insertButton,deleteButton,updateButton);

}

    private void openOrdersWindow() {
        Stage ordersStage = new Stage();
        ordersStage.setTitle("Orders");
        //TableView<Order> tableView = new TableView<>();
        TableColumn<Order2, Integer> orderIdCol = new TableColumn<>("Order ID");
        orderIdCol.setCellValueFactory(data -> data.getValue().orderIdProperty().asObject());

        TableColumn<Order2, String> customerNameCol = new TableColumn<>("Customer Name");
        customerNameCol.setCellValueFactory(data -> data.getValue().customerNameProperty());

        TableColumn<Order2, Double> totalPriceCol = new TableColumn<>("Total Price");
        totalPriceCol.setCellValueFactory(data -> data.getValue().totalPriceProperty().asObject());

        tableView2.getColumns().addAll(orderIdCol, customerNameCol, totalPriceCol);

        ObservableList<Order2> orders = fetchOrdersFromDatabase();
        tableView2.setItems(orders);
        
        Button deleteOButton = new Button("delete selected order");
    deleteOButton.setOnAction(e -> handleDeleteOrder());
    deleteOButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
        
        tableView2.setRowFactory(tv -> new TableRow<Order2>() {
    @Override
    protected void updateItem(Order2 item, boolean empty) {
        super.updateItem(item, empty);
        if (item == null || empty) {
            setStyle("");
        } else {
            // Specify conditions to hide rows based on the data values
            if (item.getOrderId() == 0) { // Example condition
                setStyle("-fx-background-color: transparent;");
            } else {
                setStyle("");
            }
        }
    }
});

        

        VBox layout = new VBox(tableView2);
        layout.setPadding(new Insets(30));
        layout.setSpacing(30);

        Scene scene = new Scene(layout, 400, 300);
        ordersStage.setScene(scene);
        ordersStage.setTitle("Orders");
        ordersStage.show();
        layout.getChildren().add(deleteOButton);
    }
    private void handleDeleteOrder() {
    Order2 selectedOrder = tableView2.getSelectionModel().getSelectedItem();
    if (selectedOrder != null) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Deletion");
        alert.setHeaderText("Delete Order");
        alert.setContentText("Are you sure you want to delete the selected order?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            tableView2.getItems().remove(selectedOrder); // Remove from TableView
            deleteOrderFromDatabase(selectedOrder); // Delete from the database
        }
    } else {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("No Order Selected");
        alert.setContentText("Please select an order to delete.");
        alert.showAndWait();
    }
}

private void deleteOrderFromDatabase(Order2 order) {
   

    String sql = "DELETE FROM food_ordering_system2.orders WHERE order_id = ?";

    try (
        Connection conn = DriverManager.getConnection(url, username, password);
        PreparedStatement statement = conn.prepareStatement(sql);
    ) {
        statement.setInt(1, order.getOrderId());
        
        int rowsDeleted = statement.executeUpdate();
        
        if (rowsDeleted > 0) {
            System.out.println("Order deleted successfully!");
        } else {
            System.out.println("Order not found or failed to delete.");
        }
    } catch (SQLException e) {
        // Handle any SQL errors
        e.printStackTrace();
    }
}

    
    
    private ObservableList<Restaurant2> fetchRestaurantsFromDatabase() {
    ObservableList<Restaurant2> restaurantsList = FXCollections.observableArrayList();
    try {
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/food_ordering_system2", username,password);
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT name,address FROM restaurant");

        while (resultSet.next()) {
            String name = resultSet.getString("name");
            String address = resultSet.getString("address");
            
            restaurantsList.add(new Restaurant2(name, address));
        }

        connection.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return restaurantsList;
}


    private ObservableList<Order2> fetchOrdersFromDatabase() {
        ObservableList<Order2> ordersList = FXCollections.observableArrayList();
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/food_ordering_system2", username, password);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT o.order_id,user.first_name,final_price.total_amount FROM food_ordering_system2.orders o join final_price on final_price.final_price_id=o.final_price_id join user on user.user_id=o.user_id;");

            while (resultSet.next()) {
                int order_Id = resultSet.getInt("order_id");
                String first_Name = resultSet.getString("first_name");
                double total_amount = resultSet.getDouble("total_amount");
                
                System.out.println("Order ID: " + order_Id + ", Customer Name: " + first_Name + ", Total Price: " + total_amount);

               
                ordersList.add(new Order2(order_Id,first_Name, total_amount));
            }

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ordersList;
    }

    public static void main(String[] args) {
        launch(args);
    }
}

class Restaurant2 {
    private  SimpleStringProperty name;
    private  SimpleStringProperty address;

    public Restaurant2(String name, String address) {
        this.name = new SimpleStringProperty(name);
        this.address = new SimpleStringProperty(address);
    }

    public String getName() {
        return name.get();
    }
    
    public String getAddress() {
        return address.get();
    }
    
    public void setName(String name) {
        this.name.set(name);
    }
    
    public void setAddress(String address) {
        this.address.set(address);
    }
    
    
    public StringProperty nameProperty() {
        return name;
    }

    
    
    public StringProperty addressProperty() {
        return address;
    }
}

class Order2 {
    private final SimpleIntegerProperty orderId;
    private final SimpleStringProperty customerName;
    private final SimpleDoubleProperty totalPrice;

    public Order2(int orderId, String customerName, double totalPrice) {
        this.orderId = new SimpleIntegerProperty(orderId);
        this.customerName = new SimpleStringProperty(customerName);
        this.totalPrice = new SimpleDoubleProperty(totalPrice);
    }

    public int getOrderId() {
        return orderId.get();
    }
    public IntegerProperty orderIdProperty() {
        return orderId;
    }

    public String getCustomerName() {
        return customerName.get();
    }
    
    public StringProperty customerNameProperty() {
        return customerName;
    }

    public double getTotalPrice() {
        return totalPrice.get();
    }
    
    public DoubleProperty totalPriceProperty() {
        return totalPrice;
    }
    
}
