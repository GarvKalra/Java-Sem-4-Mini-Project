/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_proj_fxml;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author 91995
 */
public class Restaurant {
    private StringProperty name;
    private StringProperty description;
    private StringProperty cuisine;
    private StringProperty phoneNumber;

    public Restaurant(String name, String description, String cuisine, String phoneNumber) {
        this.name = new SimpleStringProperty(name);
        this.description = new SimpleStringProperty(description);
        this.cuisine = new SimpleStringProperty(cuisine);
        this.phoneNumber = new SimpleStringProperty(phoneNumber);
    }

     public String getName() {
        return name.get();
    }
    
   public StringProperty nameProperty() {
        return name;
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    public StringProperty cuisineProperty() {
        return cuisine;
    }

    public StringProperty phoneNumberProperty() {
        return phoneNumber;
    }

    
}

