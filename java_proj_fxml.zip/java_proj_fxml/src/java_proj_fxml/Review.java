/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_proj_fxml;

/**
 *
 * @author 91995
 */
import java.time.LocalDate;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Review {

    private final IntegerProperty rating;
    private final StringProperty comment;
    private final ObjectProperty<LocalDate> reviewDate;

    public Review(int rating, String comment, LocalDate reviewDate) {
        this.rating = new SimpleIntegerProperty(rating);
        this.comment = new SimpleStringProperty(comment);
        this.reviewDate = new SimpleObjectProperty<>(reviewDate);
    }

    public int getRating() {
        return rating.get();
    }

    public void setRating(int value) {
        rating.set(value);
    }

    public IntegerProperty ratingProperty() {
        return rating;
    }

    public String getComment() {
        return comment.get();
    }

    public void setComment(String value) {
        comment.set(value);
    }

    public StringProperty commentProperty() {
        return comment;
    }

    public LocalDate getReviewDate() {
        return reviewDate.get();
    }

    public void setReviewDate(LocalDate value) {
        reviewDate.set(value);
    }

    public ObjectProperty<LocalDate> reviewDateProperty() {
        return reviewDate;
    }
}
