


package java_proj_fxml;


import javafx.application.Application;
import javafx.beans.property.*;
import javafx.scene.control.*;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;
import java.util.Optional;
import javafx.collections.ObservableList;
import javafx.scene.control.TextInputDialog;
import javafx.scene.input.MouseEvent;


import java.sql.*;

public class FoodItemsGui extends Application {

    private String password = "#Blossom84#";
    private static final int WINDOW_WIDTH = 800;
    private static final int WINDOW_HEIGHT = 600;
    private static final int TABLE_WIDTH = 750;
    private static final int TABLE_HEIGHT = 300; // Reduce the height to make space for the new table
    TableView<FoodItem> tableView = new TableView<>();
    TableView<OrderItem> finalOrderTableView = new TableView<>(); // New table for displaying final order
    Label totalPriceLabel = new Label(); // Label for displaying total price
    
    private Restaurant selectedRestaurant;

    public FoodItemsGui(Restaurant selectedRestaurant) {
        this.selectedRestaurant = selectedRestaurant;
    }

    @Override
    public void start(Stage primaryStage) {
        Label titleLabel = new Label("Food Items");
        titleLabel.setFont(new Font("System Bold", 18));

        TableColumn<FoodItem, String> nameColumn = new TableColumn<>("Dish Name");
        nameColumn.setCellValueFactory(data -> data.getValue().nameProperty());

        TableColumn<FoodItem, String> descriptionColumn = new TableColumn<>("Description");
        descriptionColumn.setCellValueFactory(data -> data.getValue().descriptionProperty());

        TableColumn<FoodItem, String> categoryColumn = new TableColumn<>("Category");
        categoryColumn.setCellValueFactory(data -> data.getValue().categoryProperty());

        TableColumn<FoodItem, String> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(data -> data.getValue().priceProperty());
        
        truncateFinalOrderTable();

        tableView.getColumns().addAll(nameColumn, descriptionColumn, categoryColumn, priceColumn);
        ObservableList<FoodItem> foodItems = getFoodItemsFromDatabase(selectedRestaurant);
        tableView.setItems(foodItems);
        tableView.setPrefSize(TABLE_WIDTH, TABLE_HEIGHT);
        Button placeOrderButton = new Button("Add item to Order");
        placeOrderButton.setOnAction(e -> placeOrder());
        
        // Create "Proceed to Checkout" button
        Button proceedToCheckoutButton = new Button("Proceed to Checkout");
        HBox hbox = new HBox(proceedToCheckoutButton);
        hbox.setSpacing(10);
        hbox.setStyle("-fx-padding: 10;");
        
        proceedToCheckoutButton.setOnAction(e -> {
            // Instantiate FoodItemsGui and call its start method
            Checkout checkout = new Checkout();
            checkout.start(new Stage());
        });
        
        VBox vbox = new VBox(titleLabel, tableView);
        vbox.setStyle("-fx-background-color: #FFFFFF;");
        vbox.setSpacing(10);
        vbox.getChildren().addAll(placeOrderButton, finalOrderTableView, totalPriceLabel);
        
        // Anchor the button to the top right corner
        AnchorPane.setTopAnchor(hbox, 20.0);
        AnchorPane.setRightAnchor(hbox, 20.0);

        AnchorPane root = new AnchorPane(vbox, hbox);
        root.setStyle("-fx-background-color: #E0E8FF;");

        AnchorPane.setTopAnchor(vbox, 20.0);
        AnchorPane.setLeftAnchor(vbox, 20.0);

        Scene scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
        primaryStage.setTitle("Food Items");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }
    
    private void truncateFinalOrderTable() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/food_ordering_system2",
                    "root", password);
            String query = "TRUNCATE TABLE finalorder";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.executeUpdate();
            connection.close();
            System.out.println("Final order table truncated.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void placeOrder() {
        ObservableList<FoodItem> selectedItems = tableView.getSelectionModel().getSelectedItems();

        if (selectedItems.isEmpty()) {
            System.out.println("No items selected for order.");
            return;
        }

        for (FoodItem item : selectedItems) {
            addItemToOrder(item);
        }
    }

    private ObservableList<FoodItem> getFoodItemsFromDatabase(Restaurant selectedRestaurant) {
        ObservableList<FoodItem> foodItems = FXCollections.observableArrayList();
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/food_ordering_system2",
                    "root", password);
            String query = "SELECT food_item.name, food_item.description, category, price FROM Food_item join restaurant on restaurant.restaurant_id=food_item.restaurant_id WHERE restaurant.name = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, selectedRestaurant.getName());
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String description = resultSet.getString("description");
                String category = resultSet.getString("category");
                String price = resultSet.getString("price");
                FoodItem foodItem = new FoodItem(name, description, category, price);
                foodItems.add(foodItem);
            }
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return foodItems;
    }

    private void addItemToOrder(FoodItem item) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Enter Quantity");
        dialog.setHeaderText("Enter the quantity for " + item.getName());
        dialog.setContentText("Quantity:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(quantityStr -> {
            try {
                int quantity = Integer.parseInt(quantityStr);
                if (quantity > 0) {
                    item.setQuantity(quantity);
                    double totalPrice = Double.parseDouble(item.getPrice()) * quantity;
                    item.setTotalPrice(totalPrice);
                    insertOrderData(item);
                } else {
                    System.out.println("Invalid quantity entered: " + quantityStr);
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid quantity entered: " + quantityStr);
            }
        });
    }

    private void insertOrderData(FoodItem item) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/food_ordering_system2",
                    "root", password);
            String query = "INSERT INTO finalorder (name, quantity, price) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, item.getName());
            statement.setInt(2, item.getQuantity());
            statement.setDouble(3, item.getTotalPrice());
            statement.executeUpdate();
            connection.close();
            System.out.println("Item added to order: " + item.getName() + ", Quantity: " + item.getQuantity() + ", Total Price: " + item.getTotalPrice());
            // Update final order table and total price label
            updateFinalOrderTable();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void updateFinalOrderTable() {
        ObservableList<OrderItem> orderItems = FXCollections.observableArrayList();
        double totalPrice = 0.0;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/food_ordering_system2",
                    "root", password);
            String query = "SELECT name, quantity, price FROM finalorder";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                int quantity = resultSet.getInt("quantity");
                double price = resultSet.getDouble("price");
                orderItems.add(new OrderItem(name, quantity, price));
                totalPrice += price;
            }
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finalOrderTableView.setItems(orderItems);
        totalPriceLabel.setText("Total Price: " + totalPrice);
    }

    public static void main(String[] args) {
        launch(args);
    }
}

class FoodItem {
    private final StringProperty name;
    private final StringProperty description;
    private final StringProperty category;
    private final StringProperty price;
    private final IntegerProperty quantity;
    private final DoubleProperty totalPrice;

    public FoodItem(String name, String description, String category, String price) {
        this.name = new SimpleStringProperty(name);
        this.description = new SimpleStringProperty(description);
        this.category = new SimpleStringProperty(category);
        this.price = new SimpleStringProperty(price);
        this.quantity = new SimpleIntegerProperty(1);
        this.totalPrice = new SimpleDoubleProperty(0);
    }

    public void setQuantity(int quantity) {
        this.quantity.set(quantity);
    }

    public int getQuantity() {
        return quantity.get();
    }
    
    public String getPrice() {
        return price.get();
    }

    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    public StringProperty categoryProperty() {
        return category;
    }

    public StringProperty priceProperty() {
        return price;
    }

    public double getTotalPrice() {
        return totalPrice.get();
    }

    public DoubleProperty totalPriceProperty() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice.set(totalPrice);
    }
}

class OrderItem {
    private final StringProperty name;
    private final IntegerProperty quantity;
    private final DoubleProperty price;

    public OrderItem(String name, int quantity, double price) {
        this.name = new SimpleStringProperty(name);
        this.quantity = new SimpleIntegerProperty(quantity);
        this.price = new SimpleDoubleProperty(price);
    }

    public String getName() {
        return name.get();
    }
    
    public Double getPrice() {
        return price.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public int getQuantity() {
        return quantity.get();
    }

    public IntegerProperty quantityProperty() {
        return quantity;
    }

    public DoubleProperty priceProperty() {
        return price;
    }
}