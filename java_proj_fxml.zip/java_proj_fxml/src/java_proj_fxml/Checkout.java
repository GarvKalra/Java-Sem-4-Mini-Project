/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package java_proj_fxml;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.control.Alert;

public class Checkout extends Application {

    private TableView<Object[]> tableView;
    private Button placeOrderButton;
    private VBox vbox;
    private Scene scene;
    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Final Orders");

        tableView = new TableView<>();
        TableColumn<Object[], Integer> idColumn = new TableColumn<>("ID");
        TableColumn<Object[], String> nameColumn = new TableColumn<>("Name");
        TableColumn<Object[], Integer> quantityColumn = new TableColumn<>("Quantity");
        TableColumn<Object[], Double> priceColumn = new TableColumn<>("Price");

        // Set cell value factory for each column
        idColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty((Integer) cellData.getValue()[0]).asObject());
        nameColumn.setCellValueFactory(cellData -> new SimpleStringProperty((String) cellData.getValue()[1]));
        quantityColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty((Integer) cellData.getValue()[2]).asObject());
        priceColumn.setCellValueFactory(cellData -> new SimpleDoubleProperty((Double) cellData.getValue()[3]).asObject());

        tableView.getColumns().addAll(idColumn, nameColumn, quantityColumn, priceColumn);

        placeOrderButton = new Button("Confirm Order");
        placeOrderButton.setOnAction(e -> calculateFinalPrice());

        vbox = new VBox(tableView, placeOrderButton);
        scene = new Scene(vbox, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();

        fetchOrdersFromDatabase();
    }

    private void fetchOrdersFromDatabase() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/food_ordering_system2", "root", "#Blossom84#");
             ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM finalorder")) {

            while (rs.next()) {
                Object[] rowData = new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("quantity"),
                        rs.getDouble("price")
                };
                tableView.getItems().add(rowData);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void calculateFinalPrice() {
        double totalPrice = 0.0;
        for (Object[] rowData : tableView.getItems()) {
            double price = (Double) rowData[3];
            int quantity = (Integer) rowData[2];
            totalPrice += price * quantity;
        }

        // Display the final price in the GUI
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("final price");
        alert.setHeaderText(null);
        String contentText = "Congrats, your order has been confirmed.\n" +
                      "Please pay the Final Price of $" + String.format("%.2f", totalPrice) + "\n" +
                      "to the deliveryman.";
        alert.setContentText(contentText);
        alert.showAndWait();
        /*VBox totalPriceBox = new VBox();
        totalPriceBox.getChildren().add(new javafx.scene.control.Label("Final Price: " + totalPrice));
        vbox.getChildren().add(totalPriceBox);*/
    }

    public static void main(String[] args) {
        launch(args);
    }
}


