

/**
 *
 * @author 91995
 */
package java_proj_fxml;

/**
 *
 * @author 91995
 */
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;



public class Main2 extends Application {

    private String password = "your_passwd";

    TableView<Restaurant> tableView = new TableView<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Label titleLabel = new Label("User Dashboard");
        titleLabel.setFont(new Font("System Bold", 18));

        Label restaurantsLabel = new Label("Restaurants");
        restaurantsLabel.setFont(new Font("System Bold", 18));

        TableColumn<Restaurant, String> restaurantColumn = new TableColumn<>("Restaurant");
        restaurantColumn.setCellValueFactory(data -> data.getValue().nameProperty());

        TableColumn<Restaurant, String> descriptionColumn = new TableColumn<>("Description");
        descriptionColumn.setCellValueFactory(data -> data.getValue().descriptionProperty());

        TableColumn<Restaurant, String> cuisineColumn = new TableColumn<>("Cuisine");
        cuisineColumn.setCellValueFactory(data -> data.getValue().cuisineProperty());

        TableColumn<Restaurant, String> phoneNumberColumn = new TableColumn<>("Phone Number");
        phoneNumberColumn.setCellValueFactory(data -> data.getValue().phoneNumberProperty());

        tableView.getColumns().addAll(restaurantColumn, descriptionColumn, cuisineColumn, phoneNumberColumn);
        ObservableList<Restaurant> restaurants = getRestaurantDataFromDatabase();
        tableView.setItems(restaurants);

        AnchorPane root = new AnchorPane();
        root.setStyle("-fx-background-color: #E0E8FF;"); 
        root.setPrefSize(800, 600); 

        root.getChildren().addAll(titleLabel, restaurantsLabel, tableView);

        titleLabel.setLayoutX(20);
        titleLabel.setLayoutY(20);

        restaurantsLabel.setLayoutX(20);
        restaurantsLabel.setLayoutY(50);

        tableView.setLayoutX(20);
        tableView.setLayoutY(80);
        tableView.setPrefSize(760, 500);

        tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                showReviewsWindow(newSelection);
            }
        });

        Scene scene = new Scene(root);
        primaryStage.setTitle("User Dashboard");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showReviewsWindow(Restaurant selectedRestaurant) {
        Stage reviewsStage = new Stage();
        reviewsStage.setTitle("Reviews for " + selectedRestaurant.getName());

        TableView<Review> reviewsTable = new TableView<>();
        TableColumn<Review, Integer> ratingColumn = new TableColumn<>("Rating");
        ratingColumn.setCellValueFactory(data -> data.getValue().ratingProperty().asObject());

        TableColumn<Review, String> commentColumn = new TableColumn<>("Comment");
        commentColumn.setCellValueFactory(data -> data.getValue().commentProperty());

        TableColumn<Review, LocalDate> reviewDateColumn = new TableColumn<>("Review_Date");
        reviewDateColumn.setCellValueFactory(data -> data.getValue().reviewDateProperty());

        reviewsTable.getColumns().addAll(ratingColumn, commentColumn, reviewDateColumn);
        reviewsTable.setItems(getReviews(selectedRestaurant));

        Button orderButton = new Button("Order food");
        orderButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");

        orderButton.setOnAction(e -> {
            FoodItemsGui foodItemsGui = new FoodItemsGui(selectedRestaurant);
            foodItemsGui.start(new Stage());
        });
        
        AnchorPane reviewsRoot = new AnchorPane();
        reviewsRoot.getChildren().addAll(reviewsTable, orderButton);

        AnchorPane.setTopAnchor(reviewsTable, 10.0);
        AnchorPane.setLeftAnchor(reviewsTable, 10.0);
        AnchorPane.setRightAnchor(reviewsTable, 10.0);
        AnchorPane.setBottomAnchor(reviewsTable, 50.0); 

        AnchorPane.setTopAnchor(orderButton, 10.0);
        AnchorPane.setRightAnchor(orderButton, 10.0);
        AnchorPane.setBottomAnchor(orderButton, 10.0);

        Scene scene = new Scene(reviewsRoot, 600, 400); 
        reviewsStage.setScene(scene);
        reviewsStage.show();
    }

    private ObservableList<Review> getReviews(Restaurant restaurant) {
        ObservableList<Review> reviewList = FXCollections.observableArrayList();
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/food_ordering_system2",
                    "root", password);
            System.out.println("func get reviews getting executed");

            String query = "SELECT reviews.rating, comment, review_date FROM reviews JOIN restaurant ON reviews.restaurant_id = restaurant.restaurant_id WHERE restaurant.name =?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, restaurant.getName()); 

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int rating = resultSet.getInt("reviews.rating");
                System.out.println(rating);
                String comment = resultSet.getString("comment");
                System.out.println(comment);
                LocalDate reviewDate = resultSet.getDate("review_date").toLocalDate();
                System.out.println(reviewDate);
                reviewList.add(new Review(rating, comment, reviewDate));
            }

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reviewList;
    }

    private ObservableList<Restaurant> getRestaurantDataFromDatabase() {
        ObservableList<Restaurant> restaurantData = FXCollections.observableArrayList();
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/food_ordering_system2",
                    "root", password);

            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT restaurant.name, description,cuisine.name,phone_number FROM restaurant join cuisine on cuisine.cuisine_id=restaurant.cuisine_id ");

            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String description = resultSet.getString("description");
                String cuisine = resultSet.getString("cuisine.name");
                String phoneNumber = resultSet.getString("phone_number");
                Restaurant restaurant = new Restaurant(name, description, cuisine, phoneNumber);
                restaurantData.add(restaurant);
            }

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return restaurantData;
    }
}


