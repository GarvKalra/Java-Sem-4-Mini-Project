/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_proj_fxml;

/**
 *
 * @author 91995
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class startPage extends Application {

    private static final int WINDOW_WIDTH = 800;
    private static final int WINDOW_HEIGHT = 600;

    @Override
    public void start(Stage primaryStage) {
        Text welcomeText = new Text("Welcome To Food Order Management");
        welcomeText.setFont(new Font(36));

        Button loginButton = new Button("Login");
        Button signUpButton = new Button("SignUp");

        Text loginText = new Text("Existing User/Admin?");
        Text signUpText = new Text("New User?");
        loginText.setFont(new Font(18));
        signUpText.setFont(new Font(18));

        loginButton.setOnAction(event -> {
            LoginApp loginApp = new LoginApp();
            loginApp.start(new Stage());
        });

        signUpButton.setOnAction(event -> {
            UserRegistrationApp userRegistrationApp = new UserRegistrationApp();
            userRegistrationApp.start(new Stage());
        });

        VBox vbox = new VBox(20);
        vbox.getChildren().addAll(welcomeText, loginText, loginButton, signUpText, signUpButton);
        vbox.setStyle("-fx-background-color: #FFEBCD; -fx-padding: 20px;"); // Faint Orange Background

        StackPane root = new StackPane(vbox);

        Scene scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
        primaryStage.setTitle("Welcome To Food Order Management");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Placeholder for the Login GUI class
    /*static class LoginApp extends Application {
        @Override
        public void start(Stage primaryStage) {
            // Your login GUI implementation
            // This is just a placeholder
            primaryStage.setTitle("Login");
            primaryStage.setScene(new Scene(new StackPane(), 400, 300));
            primaryStage.show();
        }
    }

    // Placeholder for the User Registration GUI class
    static class UserRegistrationApp extends Application {
        @Override
        public void start(Stage primaryStage) {
            // Your user registration GUI implementation
            // This is just a placeholder
            primaryStage.setTitle("User Registration");
            primaryStage.setScene(new Scene(new StackPane(), 400, 300));
            primaryStage.show();
        }
    }*/

    public static void main(String[] args) {
        launch(args);
    }
}
