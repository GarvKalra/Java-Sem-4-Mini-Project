/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_proj_fxml;


//import JavaFXApplication1.MainDashboard;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class LoginApp extends Application {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/food_ordering_system2";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "#your_passwd";

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Login");

        Label emailLabel = new Label("Email:");
        Label passwordLabel = new Label("Password:");
        TextField emailField = new TextField();
        PasswordField passwordField = new PasswordField();
        RadioButton userRadioButton = new RadioButton("User");
        RadioButton adminRadioButton = new RadioButton("Admin");
        ToggleGroup toggleGroup = new ToggleGroup();
        userRadioButton.setToggleGroup(toggleGroup);
        adminRadioButton.setToggleGroup(toggleGroup);
        userRadioButton.setSelected(true);

        Button loginButton = new Button("Login");
        loginButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        Label successLabel = new Label();
        successLabel.setTextFill(javafx.scene.paint.Color.GREEN);
        successLabel.setVisible(false);

        loginButton.setOnAction(event -> {
            String email = emailField.getText();
            String password = passwordField.getText();

            if (isValidEmail(email)) {
                if (userRadioButton.isSelected()) {
                    if (isValidUserCredentials(email, password)) {
                        System.out.println("User Login Successful!");
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Login Successful!");
                        alert.setHeaderText(null);
                        alert.setContentText("User logged in successfully!");
                        alert.showAndWait();
                        successLabel.setText("Login Successful!");
                        successLabel.setVisible(true);
                        openMain2GUI(primaryStage);
                    } else {
                        displayError("Invalid Credentials", "Invalid email or password.");
                    }
                } else if (adminRadioButton.isSelected()) {
                    if (isValidAdminCredentials(email, password)) {
                        System.out.println("Admin Login Successful!");
                        successLabel.setText("Login Successful!");
                        successLabel.setVisible(true);
                        openMainDashboard(primaryStage);
                    } else {
                        displayError("Invalid Credentials", "Invalid email or password.");
                    }
                }
            } else {
                displayError("Invalid Email", "Please enter a valid email address.");
            }
        });

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20, 20, 20, 20));
        gridPane.setVgap(10);
        gridPane.setHgap(10);
        gridPane.add(emailLabel, 0, 0);
        gridPane.add(emailField, 1, 0);
        gridPane.add(passwordLabel, 0, 1);
        gridPane.add(passwordField, 1, 1);
        gridPane.add(userRadioButton, 0, 2);
        gridPane.add(adminRadioButton, 1, 2);
        gridPane.add(loginButton, 1, 3);
        gridPane.add(successLabel, 1, 4);
        gridPane.setAlignment(Pos.CENTER);

        BackgroundFill backgroundFill = new BackgroundFill(javafx.scene.paint.Color.rgb(224, 232, 255), CornerRadii.EMPTY, Insets.EMPTY);
        Background background = new Background(backgroundFill);
        gridPane.setBackground(background);
        Scene scene = new Scene(gridPane, 400, 300);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&-]+(?:\\.[a-zA-Z0-9_+&-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return Pattern.matches(emailRegex, email);
    }

    private boolean isValidUserCredentials(String email, String password) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM account WHERE email = ? AND password = ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean isValidAdminCredentials(String email, String password) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM admin WHERE email = ? AND password = ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void displayError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void openMain2GUI(Stage primaryStage) {
        Main2 main2 = new Main2();
        main2.start(primaryStage);
    }

    private void openMainDashboard(Stage primaryStage) {
        MainDashboard mainDashboard = new MainDashboard();
        mainDashboard.start(primaryStage);
    }
}
